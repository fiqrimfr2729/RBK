
    <br>
    <center>
        <div class="page-footer">
            <div class="page-footer-inner container-fluid container-lf-space">
                <p class="page-footer-copyright">2019 &copy; Sistem Bimbingan Konseling SMAN 1 Sukagumiwang</p>
                <!-- <p class="page-footer-copyright">&nbsp;</p> -->
            </div>
            <div class="go2top">
                <i class="icon-arrow-up"></i>
            </div>
        </div>
    </center>

    <!-- BEGIN CORE PLUGINS -->
    <script src="<?php echo base_url(); ?>assets/users/global/plugins/jquery.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>assets/users/global/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>assets/users/global/plugins/bootstrap-hover-dropdown/bootstrap-hover-dropdown.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>assets/users/global/plugins/jquery-slimscroll/jquery.slimscroll.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>assets/users/global/plugins/jquery.blockui.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>assets/users/global/plugins/uniform/jquery.uniform.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>assets/users/global/plugins/bootstrap-switch/js/bootstrap-switch.min.js" type="text/javascript"></script>
    <!-- END CORE PLUGINS -->

    <!-- BEGIN PAGE LEVEL PLUGINS -->
    <script src="<?php echo base_url(); ?>assets/users/global/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>assets/users/global/plugins/bootstrap-select/js/bootstrap-select.min.js" type="text/javascript"></script>

    <script src="<?php echo base_url(); ?>assets/users/global/plugins/morris/morris.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>assets/users/global/plugins/morris/raphael-min.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>assets/users/global/plugins/counterup/jquery.waypoints.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>assets/users/global/plugins/counterup/jquery.counterup.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>assets/users/global/plugins/jquery.sparkline.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>assets/users/global/plugins/bootstrap-fileinput/bootstrap-fileinput.js" type="text/javascript"></script>

    <!-- TAMBAH SWEET ALERT YA -->
    <script src="<?=base_url()?>assets/users/scripts/sweetalert.min.js" type="text/javascript"></script>

    <script src="<?=base_url()?>assets/users/global/scripts/datatable.js" type="text/javascript"></script>
    <script src="<?=base_url()?>assets/users/global/plugins/datatables/datatables.min.js" type="text/javascript"></script>
    <script src="<?=base_url()?>assets/users/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.js" type="text/javascript"></script>
    <script src="<?=base_url()?>assets/users/global/plugins/ckeditor/ckeditor.js" type="text/javascript"></script>

    <!-- BEGIN PAGE LEVEL SCRIPTS -->
    <script src="<?=base_url()?>assets/users/pages/scripts/table-datatables-responsive.min.js" type="text/javascript"></script>
    <!-- END PAGE LEVEL SCRIPTS -->

    <script src="<?php echo base_url(); ?>assets/users/global/plugins/ckeditor/ckeditor.js" type="text/javascript"></script>

    <!-- datedropper 3 -->
    <script src="<?php echo base_url(); ?>assets/users/global/plugins/datedropper3/datedropper.js" type="text/javascript"></script>

    <!-- swiper 4.4.1 -->
    <script src="<?php echo base_url(); ?>assets/users/global/plugins/swiper/js/swiper.min.js" type="text/javascript"></script>

    <!-- END PAGE LEVEL PLUGINS -->

    <!-- BEGIN THEME GLOBAL SCRIPTS -->
    <script src="<?php echo base_url(); ?>assets/users/global/scripts/app.min.js" type="text/javascript"></script>
    <!-- END THEME GLOBAL SCRIPTS -->

    <!-- BEGIN PAGE LEVEL SCRIPTS -->
    <script src="<?php echo base_url(); ?>assets/users/pages/scripts/components-bootstrap-select.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>assets/users/pages/scripts/dashboard.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>assets/users/pages/scripts/components-date-time-pickers.min.js" type="text/javascript"></script>

    <!-- <script src="<?php echo base_url(); ?>assets/users/pages/scripts/table-datatables-responsive.min.js" type="text/javascript"></script> -->
    <!-- END PAGE LEVEL SCRIPTS -->
    <!-- BEGIN THEME LAYOUT SCRIPTS -->
    <script src="<?php echo base_url(); ?>assets/users/layouts/layout7/scripts/layout.min.js" type="text/javascript"></script>
    <!-- END THEME LAYOUT SCRIPTS -->

    <script type="text/javascript">
        var base_url = '<?php echo base_url(); ?>';
    </script>

    <script type="text/javascript">
        var burl = $('#base_url').val();

        $(document).ready(function(){
            $('.buttons-print').hide();
            $('.buttons-pdf').hide();
            $('.buttons-csv').hide();
        });
    </script>
</body>

</html>
