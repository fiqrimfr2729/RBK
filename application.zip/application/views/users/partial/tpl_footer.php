<!-- <br>
<center>
<div class="page-footer">
    <div class="page-footer-inner container-fluid container-lf-space">
        <p class="page-footer-copyright">2029 &copy; Sistem Bimbingan Konseling SMK Negeri 1 Losarang</p>
 -->        <!-- <p class="page-footer-copyright">&nbsp;</p> -->
    <!-- </div>
    <div class="go2top">
        <i class="icon-arrow-up"></i>
    </div>
</div>
</center> -->